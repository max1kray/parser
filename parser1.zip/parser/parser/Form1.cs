﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;
using System.Diagnostics;
using System.Threading;
using Excel;
using System.Text.RegularExpressions;





namespace parser
{
    public partial class Form1 : Form
    {
        private string FileName = null;
        private string ex = null;
        private string str = null;
        private string DirName = null;
        private string date = DateTime.Now.ToString();
        private DataTable Table = new DataTable();
        public static FileInfo fileInf;
        private DataSet result = null;    
        
       

        public Form1()
        {
            InitializeComponent();
        }

        public void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog OFD = new OpenFileDialog();
            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.Filter = "Excel (*.XLS)|*.XLS";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;

            if (OFD.ShowDialog() == DialogResult.OK && OFD.FileName != null)  // просим юзера указать файл таблицы
            {
                try
                {
                    FileName = OFD.FileName;
                    fileInf = new FileInfo(FileName);
                    label1.Text = fileInf.ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                }
                Process(fileInf);
            }
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog FBD = new FolderBrowserDialog();
            if (FBD.ShowDialog() == DialogResult.OK && FBD.SelectedPath != null)     // просим юзера указать папку
            {
                try
                {
                    DirName = FBD.SelectedPath;
                }

                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read dir from disk. Original error: " + ex.Message);
                }
                label2.Text = DirName;
            }
        }


        /*******************************************************************************************************************************************************************/


            private void GenTable(DataSet ds)
        {
            dataGridView1.Rows.Clear();
            result = ds;                                                                                          //чтение данных
            Table = result.Tables[0];                                                                             //получение таблицы
                                                                                                                  //  dataGridView1.DataSource = Table;

            for (int i = 0; i < Table.Rows.Count; i++)
            {
                if (Table.Rows[i][1].ToString() != "")
                    dataGridView1.Rows.Add(Table.Rows[i][1].ToString());   // рисуем таблицу
                else continue;
            }           
        }


            private void Process(FileInfo _file)
        {
            //-------------запуск таймера------------------------------------------------------------------------------------//
            Stopwatch sw_total = new Stopwatch();
            sw_total.Start();

            //------------чтение excel таблицы -----------------------------------------------------------------------------//
            FileStream stream = File.Open(_file.FullName, FileMode.Open, FileAccess.Read);                                  //создание потока для чтения
            IExcelDataReader excelReader;                                                                                   //инициализация интерфейса excel таблицы

            if (Path.GetExtension(_file.FullName).ToUpper() == ".XLS")                                  //--- в зависимости от типа файла
            {
                excelReader = ExcelReaderFactory.CreateBinaryReader(stream);                            //--- инициализированный интерфейс
                ex = ".xls";
            }
            else if (Path.GetExtension(_file.FullName).ToUpper() == ".XLSX")                            //--- чтения excel таблицы
            {                                                                                           //--- создаётся различными методами
                excelReader = ExcelReaderFactory.CreateOpenXmlReader(stream);
                ex = ".xlsx";
            }
            else throw new Exception("Неизвестный формат файла!");                                      //--- ..при неизвестном типе - ошибка

            GenTable(excelReader.AsDataSet());
            excelReader.Close();                                                                                            //закрытие потока чтения excel файла

            //-------------вывод результата таймера----------------------------------------------------------------------//
            sw_total.Stop();
           // timer1.Items.Add("Reading: " + sw_total.ElapsedMilliseconds + " ms");

        }


        /*******************************************************************************************************************************************************************/




        private void button1_Click(object sender, EventArgs e)
        {
            // Table.Clear();

            // DataTable dt = new DataTable();

            // MessageBox.Show(dataGridView1.);

            readOnlyTextBox1.Text = "";

            string s = textBox1.Text;
            Regex regex = new Regex("\n \\/:*?<>|");
            MatchCollection matches = regex.Matches(s);

            if (fileInf != null && DirName != null && textBox1.Text != "")
            {

                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    DataRow dRow = Table.NewRow();
                    foreach (DataGridViewCell cell in row.Cells)
                    {
                        dRow[cell.ColumnIndex] = cell.Value;
                    }
                    Table.Rows.Add(dRow);
                }





                try
                {
                    str = DirName + "\\" + textBox1.Text + ex;
                    StreamWriter wr = new StreamWriter(str, true, Encoding.UTF8);
                    MessageBox.Show(str);
                    for (int i = 0; i < (Table.Rows.Count); i++)
                    {


                        if (Table.Rows[i][1] != null)
                        {
                            //  wr.Write(Convert.ToString(Table.Rows[i][1]) + "\t");
                            wr.Write(Table.Rows[i][1].ToString() + "\t");
                        }
                        else
                        {
                            wr.Write("\t");
                        }

                        //go to next line
                        wr.WriteLine();

                    }
                    wr.Close();
                }
                catch (Exception ex)
                {
                    if (ex.Message == "Данный формат пути не поддерживается.")
                    {
                        MessageBox.Show("Ошибка. Имя файла не должно содержать следующих знаков:\n \\/:*?<>|");
                        MessageBox.Show(str);
                    }


                }
            }

            else
            {
                    if (fileInf == null)
                    {
                        if (readOnlyTextBox1.Lines.Count() == 0)
                        readOnlyTextBox1.Text = readOnlyTextBox1.Text + (readOnlyTextBox1.Lines.Count() + 1) + ". Файл таблицы не выбран\r\n";
                        else
                        readOnlyTextBox1.Text = readOnlyTextBox1.Text + readOnlyTextBox1.Lines.Count() + ". Файл таблицы не выбран\r\n";
                    }
                    if (DirName == null)
                    {
                        
                        if (readOnlyTextBox1.Lines.Count() == 0)
                        readOnlyTextBox1.Text = readOnlyTextBox1.Text + (readOnlyTextBox1.Lines.Count() + 1) + ". Путь конечного файла не выбран\r\n";
                        else 
                        readOnlyTextBox1.Text = readOnlyTextBox1.Text + readOnlyTextBox1.Lines.Count() + ". Путь конечного файла не выбран\r\n";
                    }
                    if (textBox1.Text == "")
                    {
                        
                        if (readOnlyTextBox1.Lines.Count() == 0)
                        readOnlyTextBox1.Text = readOnlyTextBox1.Text + (readOnlyTextBox1.Lines.Count() + 1) + ". Не задано имя конечного файла\r\n";
                        else 
                        readOnlyTextBox1.Text = readOnlyTextBox1.Text + readOnlyTextBox1.Lines.Count() + ". Не задано имя конечного файла\r\n";
                    }

                    //****************************************************
               

                if (matches.Count > 0)
                {

                    MessageBox.Show("y");
                 
                }
                else
                {
                    //Console.WriteLine("Совпадений не найдено");
                    MessageBox.Show("n");
                   // Console.ReadKey();

                }
                //*******************************************************

                return;
            }
            

            /*

            catch (IndexOutOfRangeException ex1)

            {
                if (ex1.Message == "Невозможно найти столбец 0.")
                { MessageBox.Show("Выберите файл таблицы и конечный путь файла!"); }
            }

            */

            
            MessageBox.Show("Файл успешно сохранён!");
            MessageBox.Show(Table.Rows[2][1].ToString());

    
        }
        

    }
}









/*


 // Create New Excel Workbook
ExcelWorkbook Wbook = new ExcelWorkbook();
ExcelCellCollection Cells = Wbook.Worksheets.Add("Sheet1").Cells;

Cells["A1"].Value = "Excel writer example (C#)";
Cells["A1"].Style.Font.Bold = true;
Cells["B1"].Value = "=550 + 5";

// Write Excel XLS file
Wbook.WriteXLS("excel_net.xls");


*/


