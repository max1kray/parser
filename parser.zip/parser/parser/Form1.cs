﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;
using System.Diagnostics;
using System.Threading;
using Excel;





namespace parser
{
    public partial class Form1 : Form
    {
        private string FileName = null;
        // private string TempFileName = "test";
        private string DirName = null;
        private DataTable Table = new DataTable();
        public static FileInfo fileInf;




        public Form1()
        {
            InitializeComponent();
        }


        public void my_button3()
            {
            OpenFileDialog OFD = new OpenFileDialog();
            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.Filter = "Excel (*.XLS)|*.XLS";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;

            if (OFD.ShowDialog() == DialogResult.OK && OFD.FileName != null)  // просим юзера указать файл таблицы
            {
                // if (openFileDialog1.FileName != null)
                try
                {
                    FileName = OFD.FileName;

                    // string path = FileName;
                     fileInf = new FileInfo(FileName);
                    MessageBox.Show(fileInf.ToString());
                    // MessageBox.Show(FileName);

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                }

            }
        }



        public void button3_Click(object sender, EventArgs e)
        {
            my_button3();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog FBD = new FolderBrowserDialog();
            if (FBD.ShowDialog() == DialogResult.OK && FBD.SelectedPath != null)     // просим юзера указать папку
            {
                try
                {
                    DirName = FBD.SelectedPath;
                    //fileInf = DirName;
                  //  FileInfo fileInf = new FileInfo(DirName);
    }

                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read dir from disk. Original error: " + ex.Message);
                }
            }
        }


        /*******************************************************************************************************************************************************************/



        private void Process(FileInfo _file)
        {
            //-------------запуск таймера------------------------------------------------------------------------------------//
            Stopwatch sw_total = new Stopwatch();
            sw_total.Start();

            //------------чтение excel таблицы -----------------------------------------------------------------------------//
            FileStream stream = File.Open(_file.FullName, FileMode.Open, FileAccess.Read);                                  //создание потока для чтения
            IExcelDataReader excelReader;                                                                                   //инициализация интерфейса excel таблицы




            if (Path.GetExtension(_file.FullName).ToUpper() == ".XLS")
            {
                //1.1 Reading from a binary Excel file ('97-2003 format; *.xls)
                excelReader = ExcelReaderFactory.CreateBinaryReader(stream);
            }
            else
            {
                //1.2 Reading from a OpenXml Excel file (2007 format; *.xlsx)
                excelReader = ExcelReaderFactory.CreateOpenXmlReader(stream);
            }




            /*


            if (_file.Extension == ".xls")
            {                                                                                                               //--- в зависимости от типа файла
                excelReader = ExcelReaderFactory.CreateBinaryReader(stream);                                                //--- инициализированный интерфейс
            }
            else if (_file.Extension == ".xlsx")
            {                                                                                                               //--- чтения excel таблицы
                excelReader = ExcelReaderFactory.CreateOpenXmlReader(stream);                                               //--- создаётся различными методами
            }
            else throw new Exception("Неизвестный формат файла!");                                                          //--- ..при неизвестном типе - ошибка

            */







            DataSet result = excelReader.AsDataSet();                                                                       //чтение данных
            DataTable table = result.Tables[0];                                                                             //получение таблицы

          //  excelReader.Close();                                                                                            //закрытие потока чтения excel файла


            dataGridView1.DataSource = table;


            /*

            //---------------заполнение массивов---------------------------------------------------------------------------//
            List<List<string>> list_table = new List<List<string>>();
            for (int j = 0; j < table.Columns.Count; j++)
            {
                List<string> list_row = new List<string>();
                for (int i = 0; i < table.Rows.Count; i++)
                    list_row.Add(table.Rows[i].ItemArray[j].ToString());
                list_table.Add(list_row);
            }

            //-------------вывод результата таймера----------------------------------------------------------------------//
            sw_total.Stop();
           // timer1.Items.Add("Reading: " + sw_total.ElapsedMilliseconds + " ms");


            */






        }


        /*******************************************************************************************************************************************************************/




        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(fileInf.ToString());
            MessageBox.Show(FileName);
            MessageBox.Show(DirName);
            Process(fileInf);
        }
    }
}









/*


 // Create New Excel Workbook
ExcelWorkbook Wbook = new ExcelWorkbook();
ExcelCellCollection Cells = Wbook.Worksheets.Add("Sheet1").Cells;

Cells["A1"].Value = "Excel writer example (C#)";
Cells["A1"].Style.Font.Bold = true;
Cells["B1"].Value = "=550 + 5";

// Write Excel XLS file
Wbook.WriteXLS("excel_net.xls");


*/


